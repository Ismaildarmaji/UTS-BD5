# UTS BASIS DATA LAB 5

nama: Ismail Darmaji

nim: 211401013

1.Tampilkan mahasiswa yang tidak tinggal di medan

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled.png)

output

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%201.png)

1. Tampilkan mahasiswa laki-laki yang tinggal di Medan

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%202.png)

output

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%203.png)

3.Tampilkan mahasiswa yang tinggal di Indonesia

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%204.png)

output

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%205.png)

4.Tampilkan satu mahasiswa yang paling muda

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%206.png)

output

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%207.png)

1. Tampilan mahasiswa yang namanya berawalan dengan huruf B

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%208.png)

output

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%209.png)

1. Tampilan mahasiswa dengan umur genap yang tidak tinggal di Medan

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%2010.png)

output

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%2011.png)

1. Tampilkan mahasiswa dengan program studi teknologi informasi dengan IPK
antara 2 dan 3

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%2012.png)

output

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%2013.png)

1. Tampilkan satu mahasiswa yang paling tua, yang tinggal di Medan

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%2014.png)

output

![Untitled](UTS%20BASIS%20DATA%20LAB%205%20be5de2cb8f0b4c29871d49c40ea1f867/Untitled%2015.png)

[](https://www.notion.so/55cc0508fdfe4cf2a817059150277b64)